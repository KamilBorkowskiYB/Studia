package Klasy;


/**
 * @author Kamil
 * @version 1.0
 * @created 19-maj-2024 14:19:44
 */
public class Film {

	private int Obsada;
	private int Oceny;
	private int Opinie;
	private int Opis;
	private int Tytu�;
	private int Zdj�cia;

	public Film(){

	}

	public void finalize() throws Throwable {

	}
	public void Dodaj do ulubinych(){

	}

	public void Obejrzyj obsade(){

	}

	public void Wyswietl zwiastun(){

	}

	public void Zobacz podobne(){

	}

	public void Zobacz seanse(){

	}
}//end Film