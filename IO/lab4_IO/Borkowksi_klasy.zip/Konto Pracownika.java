

/**
 * @author Kamil
 * @version 1.0
 * @created 19-maj-2024 14:20:10
 */
public class Konto Pracownika extends Konto Klienta {

	private string Dyspozycyjnosc;
	private string Grafik;
	private int Numer konta banowego;
	private float Przepracowane godziny;
	private Stanowisko* Stanowisko;

	public Konto Pracownika(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
	public void Edytuj dyspozycyjnos�(){

	}

	public void Podgl�d danych(){

	}

	public void Sprawd� grafik(){

	}

	public void Zg�os dyspozycyjnos�(){

	}
}//end Konto Pracownika