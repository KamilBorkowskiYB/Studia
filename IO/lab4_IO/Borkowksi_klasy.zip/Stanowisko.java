package Klasy;


/**
 * @author Kamil
 * @version 1.0
 * @created 19-maj-2024 14:20:12
 */
public class Stanowisko {

	private string Nazwa stanowiska;
	private string Opis stanowiska;
	private string Pozycja stanowiska;

	public Stanowisko(){

	}

	public void finalize() throws Throwable {

	}
	public void Dodaj nowe stanowisko(){

	}

	public void Edytuj nazw�(){

	}

	public void Edytuj opis(){

	}

	public void Usu� stanowisko(){

	}

	public void Wyswietl opis(){

	}
}//end Stanowisko