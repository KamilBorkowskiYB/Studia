

/**
 * @author Kamil
 * @version 1.0
 * @created 19-maj-2024 14:20:13
 */
public class System Wyszukiwania {

	private Film* Baza film�w[];
	private Kino* Baza kin[];
	private Filtr* Lista filtr�w[];
	public Konto U�ytkownika m_Konto U�ytkownika;

	public System Wyszukiwania(){

	}

	public void finalize() throws Throwable {

	}
	public void U�yj filtr�w(){

	}

	public void Wyswietl wyniki(){

	}

	public void Wyszukaj film(){

	}

	public void Wyszukaj kino(){

	}
}//end System Wyszukiwania