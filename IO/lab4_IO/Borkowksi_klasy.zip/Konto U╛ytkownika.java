

/**
 * @author Kamil
 * @version 1.0
 * @created 19-maj-2024 14:20:11
 */
public class Konto U�ytkownika extends Konto Klienta {

	private Konto U�ytkownika* Lista obserwowanych u�ytkownik�w[];
	private int Oceny;
	private string Opinie;
	private int Punkty lojalnosciowe;
	private Film* Ulubione filmy[];

	public Konto U�ytkownika(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
	public void Op�a� seans(){

	}

	public void Op�a� seans(){

	}

	public void Usu� konto(){

	}

	public void Wyszukiwanie(){

	}

	public void Za�� konto(){

	}

	public void Zarezerwuj seans(){

	}

	public void Zg�os u�ytkownika(){

	}
}//end Konto U�ytkownika