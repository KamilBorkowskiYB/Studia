import Klasy.Kino;

/**
 * @author Kamil
 * @version 1.0
 * @created 19-maj-2024 14:20:09
 */
public class Konto Menad�era extends Konto Klienta {

	private Kontrahent* Kontakty do kontrahent�w[];
	private Kino* Lista zarz�dzanych kin[];
	private Konto Pracownika* Podlegli pracownicy[];
	public Konto Pracownika m_Konto Pracownika;
	public Kino m_Kino;

	public Konto Menad�era(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
	public void Dodanie stanowiska pracowniczego(){

	}

	public void Edycja listy kontrahent�w(){

	}

	public void Podglad danych pracownika(){

	}

	public void Tworzenie konta pracownika(){

	}

	public void Ustawianie grafiku pracownika(){

	}

	public void Usuniecie stanowiska pracowniczego(){

	}

	public void Usuwanie konta pracownika(){

	}
}//end Konto Menad�era