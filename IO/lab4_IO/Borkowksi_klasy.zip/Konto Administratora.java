

/**
 * @author Kamil
 * @version 1.0
 * @created 19-maj-2024 14:20:06
 */
public class Konto Administratora extends Konto Klienta {

	private Zg�oszenie* Lista odwo�a�[];
	private Konto Klienta* Lista zablokowanych kont[];
	private Konto Klienta* Lista zawieszonych kont[];
	private Zg�oszenie* Lista zgloszen[];

	public Konto Administratora(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
	public void Odwies konto(){

	}

	public void Poinformuj o pracach technicznych(){

	}

	public void Usu� konto(){

	}

	public void Wyslij ostrze�enie(){

	}

	public void Zawies konto(){

	}
}//end Konto Administratora