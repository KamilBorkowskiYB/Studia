package Klasy;


/**
 * @author Kamil
 * @version 1.0
 * @created 19-maj-2024 14:20:04
 */
public class Kino {

	private string Adres;
	private string Domena internetowa;
	private string Godziny otwarcia;
	private Stanowisko* Lista stanowisk[];
	private string Nazwa kina;
	private Konto Pracownika* Pracownicy[];
	private Film* Repertuar[];
	public Konto Pracownika m_Konto Pracownika;
	public Stanowisko m_Stanowisko;

	public Kino(){

	}

	public void finalize() throws Throwable {

	}
}//end Kino