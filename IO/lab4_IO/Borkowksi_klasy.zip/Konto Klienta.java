

/**
 * @author Kamil
 * @version 1.0
 * @created 19-maj-2024 14:20:07
 */
public abstract class Konto Klienta {

	protected int awatar;
	protected string e-mail;
	protected string has�o;
	protected int id;
	protected string Nazwa Klienta;
	protected boolean Zablokowane;
	protected boolean Zawieszone;

	public Konto Klienta(){

	}

	public void finalize() throws Throwable {

	}
	public void Wyloguj(){

	}

	public void Zaloguj(){

	}

	public void Zmien has�o(){

	}

	public void Zmie� j�zyk(){

	}

	public void Zmie� motyw(){

	}
}//end Konto Klienta